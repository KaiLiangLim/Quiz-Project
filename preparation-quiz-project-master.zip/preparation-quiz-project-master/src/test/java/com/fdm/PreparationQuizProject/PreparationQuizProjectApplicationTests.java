package com.fdm.PreparationQuizProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PreparationQuizProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
